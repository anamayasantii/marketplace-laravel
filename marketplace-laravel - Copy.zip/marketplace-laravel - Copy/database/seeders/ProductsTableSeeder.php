<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Product;

class ProductsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $now = now();
        DB::table('products')->insert([
            'name' => 'Chocolatos Dark Chocolate',
            'price' => 1000,
            'stock' => 48,
            'brand_id' => 1,  // Menghubungkan dengan brand Chocolatos
            'category_id' => 1,  // Menghubungkan dengan kategori Makanan
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        DB::table('products')->insert([
            'name' => 'Chitato Keju',
            'price' => 10000,
            'stock' => 21,
            'brand_id' => 2,  // Menghubungkan dengan brand Chitato
            'category_id' => 1,  // Menghubungkan dengan kategori Makanan
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        DB::table('products')->insert([
            'name' => 'Ultra Milk Coklat',
            'price' => 6000,
            'stock' => 12,
            'brand_id' => 3,  // Menghubungkan dengan brand Ultra Milk
            'category_id' => 2,  // Menghubungkan dengan kategori Minuman
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        DB::table('products')->insert([
            'name' => 'Magnum Almonds',
            'price' => 15000,
            'stock' => 5,
            'brand_id' => 4,  // Menghubungkan dengan brand Magnum
            'category_id' => 1,  // Menghubungkan dengan kategori Makanan
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        DB::table('products')->insert([
            'name' => 'Oreo Original',
            'price' => 10000,
            'stock' => 25,
            'brand_id' => 5,  // Menghubungkan dengan brand Oreo
            'category_id' => 1,  // Menghubungkan dengan kategori Makanan
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        DB::table('products')->insert([
            'name' => 'Tango Wafer Cokelat',
            'price' => 8000,
            'stock' => 20,
            'brand_id' => 6,  // Menghubungkan dengan brand Tango
            'category_id' => 1,  // Menghubungkan dengan kategori Makanan
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        DB::table('products')->insert([
            'name' => 'Beng Beng Cokelat',
            'price' => 5000,
            'stock' => 30,
            'brand_id' => 7,  // Menghubungkan dengan brand Beng Beng
            'category_id' => 1,  // Menghubungkan dengan kategori Makanan
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        DB::table('products')->insert([
            'name' => 'Piattos BBQ',
            'price' => 9000,
            'stock' => 15,
            'brand_id' => 8,  // Menghubungkan dengan brand Piattos
            'category_id' => 1,  // Menghubungkan dengan kategori Makanan
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        DB::table('products')->insert([
            'name' => 'Doritos Nacho Cheese',
            'price' => 15000,
            'stock' => 10,
            'brand_id' => 9,  // Menghubungkan dengan brand Doritos
            'category_id' => 1,  // Menghubungkan dengan kategori Makanan
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        DB::table('products')->insert([
            'name' => 'Cheetos Puff',
            'price' => 12000,
            'stock' => 18,
            'brand_id' => 10, // Menghubungkan dengan brand Cheetos
            'category_id' => 1,  // Menghubungkan dengan kategori Makanan
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        DB::table('products')->insert([
            'name' => 'Cimory Yogurt',
            'price' => 15000,
            'stock' => 8,
            'brand_id' => 11, // Menghubungkan dengan brand Cimory
            'category_id' => 2, // Menghubungkan dengan kategori Minuman
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        DB::table('products')->insert([
            'name' => 'Walls Es Krim Vanila',
            'price' => 12000,
            'stock' => 5,
            'brand_id' => 12, // Menghubungkan dengan brand Walls
            'category_id' => 1,  // Menghubungkan dengan kategori Makanan
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        DB::table('products')->insert([
            'name' => 'Chocolatos Hazelnut',
            'price' => 1000,
            'stock' => 50,
            'brand_id' => 1,  // Menghubungkan dengan brand Chocolatos
            'category_id' => 1,  // Menghubungkan dengan kategori Makanan
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        DB::table('products')->insert([
            'name' => 'Chitato Rasa Sapi Panggang',
            'price' => 12000,
            'stock' => 15,
            'brand_id' => 2,  // Menghubungkan dengan brand Chitato
            'category_id' => 1,  // Menghubungkan dengan kategori Makanan
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        DB::table('products')->insert([
            'name' => 'Ultra Milk Karamel',
            'price' => 6000,
            'stock' => 12,
            'brand_id' => 3,  // Menghubungkan dengan brand Ultra Milk
            'category_id' => 2,  // Menghubungkan dengan kategori Minuman
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        DB::table('products')->insert([
            'name' => 'Magnum Classic',
            'price' => 15000,
            'stock' => 7,
            'brand_id' => 4,  // Menghubungkan dengan brand Magnum
            'category_id' => 1,  // Menghubungkan dengan kategori Makanan
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        DB::table('products')->insert([
            'name' => 'Oreo Double Stuf',
            'price' => 11000,
            'stock' => 30,
            'brand_id' => 5,  // Menghubungkan dengan brand Oreo
            'category_id' => 1,  // Menghubungkan dengan kategori Makanan
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        DB::table('products')->insert([
            'name' => 'Tango Wafer Tiramisu',
            'price' => 8500,
            'stock' => 20,
            'brand_id' => 6,  // Menghubungkan dengan brand Tango
            'category_id' => 1,  // Menghubungkan dengan kategori Makanan
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        DB::table('products')->insert([
            'name' => 'Beng Beng Max',
            'price' => 6000,
            'stock' => 30,
            'brand_id' => 7,  // Menghubungkan dengan brand Beng Beng
            'category_id' => 1,  // Menghubungkan dengan kategori Makanan
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        //Product::factory()->count(80)->create();
    }
}
